"""
高校新闻采集模块
"""
from flask import Blueprint, request, render_template, jsonify
import adminProcess
from Controller.Data2DB import mylog

news = Blueprint("news", __name__)
log0 = mylog()


@news.route("/admin/news_1")
def result_news_1():
    # 获取来源的参数
    page = request.args.get('page')
    print(page)
    if page is None:
        page = 1
    elif page == "0":
        page = 1
    elif page == "10":
        page = 10

    # 增加获取一共多少页的代码
    tableName = 'university_1'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['news'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/news.html", data=data)



@news.route("/admin/news_2")
def result_news_2():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None:
        page = 1
    # 增加获取一共多少页的代码
    tableName = 'university_2'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['news'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/news.html", data=data)


@news.route("/admin/news_3")
def result_news_3():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None:
        page = 1
    tableName = 'university_3'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['news'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/news.html", data=data)


@news.route("/admin/news_4")
def result_news_4():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None:
        page = 1
    # 增加获取一共多少页的代码
    data = {}
    tableName = 'university_4'
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['news'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/news.html", data=data)


'''处理新闻数据采集'''


@news.route("/admin/newsCollect")
def newsCollect():
    sourceID = request.args.get('source')
    if adminProcess.newsFetch(sourceID):
        return jsonify({'code': 200, 'msg': "爬取成功！"})
    else:
        return jsonify({'code': 200, 'msg': '爬取失败！'})

@news.route("/news_1")
def show_1():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName='university_1')
    data['currentPage'] = int(page)
    data['news'] = adminProcess.getDataListByPage(tableName='university_1', page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/news.html", data=data)
@news.route("/news_2")
def show_2():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName='university_2')
    data['currentPage'] = int(page)
    data['news'] = adminProcess.getDataListByPage(tableName='university_2', page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/news.html", data=data)
@news.route("/news_3")
def show_3():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName='university_3')
    data['currentPage'] = int(page)
    data['news'] = adminProcess.getDataListByPage(tableName='university_3', page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/news.html", data=data)
@news.route("/news_4")
def show_4():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName='university_4')
    data['currentPage'] = int(page)
    data['news'] = adminProcess.getDataListByPage(tableName='university_4', page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/news.html", data=data)
'''处理新闻数据删除'''







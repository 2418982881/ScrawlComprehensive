"""
热榜采集模块
"""
from flask import Blueprint, request, render_template, jsonify
import adminProcess
from Controller.Data2DB import mylog

rb = Blueprint("rb", __name__)
log0 = mylog()


@rb.route("/admin/rb_1")
def result_rb():
    print("热榜成功")
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    tableName = 'society_1'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['rb'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/rb.html", data=data)

@rb.route("/admin/rb_2")
def result_rb_bilibili():
    print("热榜成功")
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    tableName = 'society_2'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['rb'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/rb.html", data=data)


@rb.route("/admin/rb_3")
def result_bd():
    print("热榜成功")
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    tableName = 'society_3'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['rb'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/rb.html", data=data)


@rb.route("/rb_1")
def rb_1():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    tableName = 'society_1'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['rb'] = adminProcess.getDataListByPage(tableName, page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/rb.html", data=data)
@rb.route("/rb_2")
def rb_2():
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName='society_2')
    data['currentPage'] = int(page)
    data['rb'] = adminProcess.getDataListByPage(tableName='society_2', page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/rb.html", data=data)
@rb.route("/rb_3")
def rb_3():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName='rb_3')
    data['currentPage'] = int(page)
    data['rb'] = adminProcess.getDataListByPage(tableName='rb_3', page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/rb.html", data=data)
'''处理新闻数据采集'''


@rb.route("/admin/rbCollect")
def newsCollect():
    sourceID = request.args.get('source')
    if adminProcess.rbFetch(sourceID):
        return jsonify({'code': 200, 'msg': "爬取成功！"})
    else:
        return jsonify({'code': 200, 'msg': '爬取失败！'})


'''处理新闻数据删除'''


@rb.route("/admin/Delete")
def newsDelete():
    kind = request.args.get('kind')
    print(kind.split(",",1))
    if adminProcess.newsDelete(kind.split(",",1)[0], kind.split(",",1)[1]):
        print("删除成功")
        return jsonify({'code': 200, 'msg': '删除成功！'})
    else:
        print("删除失败")
        return jsonify({'code': 404, 'msg': '删除不成功！'})



'''处理新闻数据显示'''


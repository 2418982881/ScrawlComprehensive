'''
全国通缉悬赏信息
'''
from flask import Blueprint, request, render_template, jsonify
import adminProcess
from Controller.Data2DB import mylog
from Controller.sjfetch import run

like = Blueprint("like", __name__)
log0 = mylog()
@like.route("/admin/likeshow")
def result():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    tableName ='mylike'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['sj'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/sj.html", data=data)
@like.route("/likeshow")
def sj_():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    tableName = 'mylike'
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['like'] = adminProcess.getDataListByPage(tableName, page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/bz.html", data=data)
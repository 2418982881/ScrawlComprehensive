'''后端请求'''
from Model import DataDB as db
from Controller import Data2DB as d2b
from Controller import DataFetch
from Controller import DataMonitor
from Model  import dbModel as  d3b

def login(name, pwd):
    '''
    登录处理
    :param name:
    :param pwd:
    :return:
    '''
    status = 0
    if db.getDataByName("admin_user", name=name):
        if pwd == db.getDataByName("admin_user", name=name)[2]:
             status = 1
        else:status=0
    elif db.getDataByName("user", name=name):
        if pwd == db.getDataByName("user", name=name)[2]:
             status = 2
        else:status=0
    return status
def zhuce(name,password):
    try:
        d3b.dbConnect().dbManage(sql = "insert into user values(null,'{}','{}',0)".format(name,password))
        print("注册成功")
    except:
        print("注册失败")




def getDataList(tableName):
    '''
    获取所有的数据
    :param tableName:
    :return:
    '''
    return db.getAllData(tableName=tableName)


def getDataListPage(tableName):
    '''
    获取数据的分页数量
    :param tableName:
    :param page:
    :return:
    '''
    return db.getAllDataPage(tableName=tableName)


def getDataListByPage(tableName, page):
    '''
    获取分页的数据
    :param tableName:
    :param page:
    :return:
    '''
    return db.getAllDataByPage(tableName=tableName, page=page)


def newsFetch(id):
    '''
    爬取新闻处理
    :param id:
    :return:
    '''
    return d2b.newsAdd(id)
def rbFetch(id):
    '''
    爬取新闻处理
    :param id:
    :return:
    '''
    return d2b.rbAdd(id)


def newsDelete(tableName, id):
    '''
    删除某一条指定的新闻
    :param id:
    :return:
    '''
    return db.delData(tableName, id)


def newsShow(tableName, id):
    '''
    显示某一条指定的新闻
    :param id:
    :return:
    '''
    return db.modifyData(tableName, 1, id)


def yqFetch(id):
    '''
    爬取疫情处理
    :param id:
    :return:
    '''
    return d2b.yqAdd(id)


def mtshow(id):
    '''
    爬取疫情处理
    :param id:
    :return:
    '''
    return d2b.mtAdd(id)




def searchdata(kw):
    '''
    模糊搜索
    :param tablename:
    :param kw:
    :return:
    '''
    return db.searchData(kw=kw)


def getsysInfo():
    '''
    获取硬件信息
    :return:
    '''
    return DataMonitor.getsysInfo()


def getSysLog(page):
    '''
    获取日志信息
    :return:
    '''
    return DataMonitor.getsysLog(page)


if __name__=="__main__":
    zhuce("name","password")
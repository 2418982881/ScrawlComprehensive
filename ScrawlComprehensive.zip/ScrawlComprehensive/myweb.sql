﻿# Host: localhost  (Version: 5.7.26)
# Date: 2022-06-21 21:47:52
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "_log505"
#

DROP TABLE IF EXISTS `_log505`;
CREATE TABLE `_log505` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ctime` varchar(100) DEFAULT NULL,
  `clineno` int(11) DEFAULT NULL,
  `cfunname` varchar(100) DEFAULT NULL,
  `cmessage` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# Data for table "_log505"
#

/*!40000 ALTER TABLE `_log505` DISABLE KEYS */;
INSERT INTO `_log505` VALUES (1,'20220505 15:45',45,'index','success');
/*!40000 ALTER TABLE `_log505` ENABLE KEYS */;

#
# Structure for table "_logs"
#

DROP TABLE IF EXISTS `_logs`;
CREATE TABLE `_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ctime` varchar(100) DEFAULT NULL,
  `clineno` int(11) DEFAULT NULL,
  `cfunname` varchar(100) DEFAULT NULL,
  `cmessage` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

#
# Data for table "_logs"
#

/*!40000 ALTER TABLE `_logs` DISABLE KEYS */;
INSERT INTO `_logs` VALUES (1,'2022-05-03 19:52:38.803020',48,'<module>','hee'),(2,'2022-05-03 20:40:05.277045',9,'index','用户进入首页'),(3,'2022-05-03 20:41:00.403009',31,'loglist','用户查看日志页'),(4,'2022-05-03 20:41:00.409603',33,'loglist','查询日志成功'),(5,'2022-05-03 20:41:19.584688',31,'loglist','用户查看日志页'),(6,'2022-05-03 20:41:19.587219',33,'loglist','查询日志成功'),(7,'2022-05-03 20:41:33.790256',33,'loglist','用户查看日志页'),(8,'2022-05-03 20:41:33.830875',35,'loglist','查询日志成功'),(9,'2022-05-03 20:43:24.502108',33,'loglist','用户查看日志页'),(10,'2022-05-03 20:43:24.538837',35,'loglist','查询日志成功'),(11,'2022-05-03 20:45:30.206053',31,'loglist','用户查看日志页'),(12,'2022-05-03 20:45:30.222065',33,'loglist','查询日志成功'),(13,'2022-05-03 20:46:37.610378',9,'index','用户进入首页'),(14,'2022-05-03 20:46:46.647252',17,'login','用户登录请求'),(15,'2022-05-03 20:46:46.648950',25,'login','admin用户密码不对，请求不成功'),(16,'2022-05-03 20:46:58.929978',32,'loglist','用户查看日志页'),(17,'2022-05-03 20:46:58.936802',34,'loglist','查询日志成功'),(18,'2022-05-03 20:51:53.229587',31,'loglist','用户查看日志页'),(19,'2022-05-03 20:51:53.257891',33,'loglist','查询日志成功');
/*!40000 ALTER TABLE `_logs` ENABLE KEYS */;

#
# Structure for table "dblog"
#

DROP TABLE IF EXISTS `dblog`;
CREATE TABLE `dblog` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ctime` varchar(255) DEFAULT NULL,
  `lineno` varchar(255) DEFAULT NULL,
  `funName` varchar(255) DEFAULT NULL,
  `msg` text,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

#
# Data for table "dblog"
#

/*!40000 ALTER TABLE `dblog` DISABLE KEYS */;
INSERT INTO `dblog` VALUES (1,'111','2','aap','okdfdfd'),(2,'111','23','app','ok'),(3,'111','23','app','ok'),(4,'2022-06-21 13:28:56.417303','16','front','获取天气成功'),(5,'2022-06-21 13:29:03.419740','60','index','进入新闻页面成功'),(6,'2022-06-21 13:29:05.394427','16','front','获取天气成功'),(7,'2022-06-21 13:29:10.526060','83','search','搜索关键词科大'),(8,'2022-06-21 13:29:15.864477','34','yqdata','获取疫情数据成功'),(9,'2022-06-21 13:39:41.210115','16','front','获取天气成功'),(10,'2022-06-21 13:39:44.235805','60','index','进入新闻页面成功'),(11,'2022-06-21 13:39:45.848499','16','front','获取天气成功'),(12,'2022-06-21 13:39:49.884153','83','search','搜索关键词科大'),(13,'2022-06-21 13:50:47.616730','16','front','获取天气成功'),(14,'2022-06-21 13:52:43.663692','16','front','获取天气成功'),(15,'2022-06-21 13:52:58.766991','60','index','进入新闻页面成功'),(16,'2022-06-21 13:53:01.541700','34','yqdata','获取疫情数据成功'),(17,'2022-06-21 13:53:03.508322','16','front','获取天气成功'),(18,'2022-06-21 13:53:07.225088','81','search','搜索关键词科大'),(19,'2022-06-21 13:53:09.330669','16','front','获取天气成功');
/*!40000 ALTER TABLE `dblog` ENABLE KEYS */;

#
# Structure for table "dbuser"
#

DROP TABLE IF EXISTS `dbuser`;
CREATE TABLE `dbuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `userpwd` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# Data for table "dbuser"
#

/*!40000 ALTER TABLE `dbuser` DISABLE KEYS */;
INSERT INTO `dbuser` VALUES (1,'admin','admin123');
/*!40000 ALTER TABLE `dbuser` ENABLE KEYS */;

#
# Structure for table "log506"
#

DROP TABLE IF EXISTS `log506`;
CREATE TABLE `log506` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ctime` varchar(50) DEFAULT NULL,
  `cname` varchar(50) DEFAULT NULL,
  `msg` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

#
# Data for table "log506"
#

/*!40000 ALTER TABLE `log506` DISABLE KEYS */;
INSERT INTO `log506` VALUES (1,'20220508 15:48','logDB','ok'),(2,'2022-05-05 16:09:58.930275','<module>','hello,ok'),(3,'2022-05-05 16:26:46.311055','<module>','hello,ok'),(4,'2022-05-05 16:26:54.013644','index','请求首页'),(5,'2022-05-05 16:26:54.016713','index','请求首页'),(6,'2022-05-05 16:27:06.299153','login','用户名对了'),(7,'2022-05-05 16:27:06.301159','login','用户名对了'),(8,'2022-05-05 16:27:06.302155','login','允许登录'),(9,'2022-05-05 16:27:06.302925','login','允许登录'),(10,'2022-05-05 16:29:46.550105','<module>','hello,ok'),(11,'2022-05-05 16:29:49.693991','index','请求首页'),(12,'2022-05-05 16:29:49.702404','index','请求首页'),(13,'2022-05-05 16:29:56.750100','login','用户名对了'),(14,'2022-05-05 16:29:56.751110','login','用户名对了'),(15,'2022-05-05 16:29:56.752112','login','密码输错，不允许登录'),(16,'2022-05-05 16:29:56.753183','login','密码输错，不允许登录'),(17,'2022-05-05 16:30:04.354692','login','用户名对了'),(18,'2022-05-05 16:30:04.356694','login','用户名对了'),(19,'2022-05-05 16:30:04.360454','login','允许登录'),(20,'2022-05-05 16:30:04.362104','login','允许登录'),(21,'2022-05-05 16:30:25.859721','<module>','hello,ok'),(22,'2022-05-05 16:30:30.411436','index','请求首页'),(23,'2022-05-05 16:30:30.414902','index','请求首页'),(24,'2022-05-05 16:31:20.164678','<module>','hello,ok'),(25,'2022-05-05 16:31:22.255476','index','请求首页'),(26,'2022-05-05 16:31:22.258205','index','请求首页'),(27,'2022-05-05 16:32:14.077759','<module>','hello,ok'),(28,'2022-05-05 16:32:15.612000','index','请求首页'),(29,'2022-05-05 16:32:15.612833','index','请求首页'),(30,'2022-05-05 16:33:30.742818','<module>','hello,ok'),(31,'2022-05-05 16:33:33.318238','index','请求首页'),(32,'2022-05-05 16:33:33.318995','index','请求首页'),(33,'2022-05-05 16:33:46.018722','<module>','hello,ok'),(34,'2022-05-05 16:33:47.823878','index','请求首页'),(35,'2022-05-05 16:33:47.831800','index','请求首页'),(36,'2022-05-05 16:34:02.943568','<module>','hello,ok'),(37,'2022-05-05 16:34:04.560468','index','请求首页'),(38,'2022-05-05 16:34:04.561480','index','请求首页'),(39,'2022-05-05 16:34:51.399473','<module>','hello,ok'),(40,'2022-05-05 16:34:53.209752','index','请求首页'),(41,'2022-05-05 16:34:53.226764','index','请求首页'),(42,'2022-05-06 08:59:24.741609','<module>','hello,ok'),(43,'2022-05-06 08:59:28.748887','index','请求首页'),(44,'2022-05-06 08:59:28.749946','index','请求首页'),(45,'2022-05-06 08:59:39.486132','login','所有都不对，不允许登录'),(46,'2022-05-06 08:59:39.486132','login','所有都不对，不允许登录'),(47,'2022-05-06 09:00:53.186731','login','用户名对了'),(48,'2022-05-06 09:00:53.187232','login','用户名对了'),(49,'2022-05-06 09:00:53.188703','login','允许登录'),(50,'2022-05-06 09:00:53.188703','login','允许登录');
/*!40000 ALTER TABLE `log506` ENABLE KEYS */;

#
# Structure for table "news"
#

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) DEFAULT NULL COMMENT '新闻来源',
  `ctime` varchar(255) DEFAULT NULL COMMENT '采集时间',
  `title` varchar(500) DEFAULT NULL COMMENT '新闻标题',
  `url` varchar(255) DEFAULT NULL COMMENT 'url链接',
  `status` int(11) DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COMMENT='新闻表';

#
# Data for table "news"
#

/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (8,'我大新闻','26\n2022.04','【媒体聚焦】人民日报等多家媒体报道第八届中国国际“互联网+”大学生创新创业大赛天津赛区启动会于天津科技大学举行','http://news.tust.edu.cn/kdxw/d85c5646552142539b87c7084684f0fe.htm',0),(9,'我大新闻','26\n2022.04','【媒体聚焦】人民日报等多家媒体报道第八届中国国际“互联网+”大学生创新创业大赛天津赛区启动会于天津科技大学举行','http://news.tust.edu.cn/kdxw/d85c5646552142539b87c7084684f0fe.htm',0),(10,'我大新闻','25\n2022.05','【媒体聚焦】中国共产党新闻网发表天科大马院赵志勇老师理论文章——思政课要善用科学思维方法讲道理','http://news.tust.edu.cn/kdxw/54f661e16b654ec8ae2ac88157828d1c.htm',0),(11,'我大新闻','25\n2022.05','【媒体聚焦】中国共产党新闻网发表天科大马院赵志勇老师理论文章——思政课要善用科学思维方法讲道理','http://news.tust.edu.cn/kdxw/54f661e16b654ec8ae2ac88157828d1c.htm',0),(12,'我大新闻','26\n2022.05','【强担当 创业绩】强强联合！天科大生物工程学院陈宁教授团队在生物医药领域取得系列重大项目','http://news.tust.edu.cn/kdxw/54f661e16b654ec8ae2ac88157828d1c.htm',0),(14,'我大新闻','25\n2022.05','【媒体聚焦】中国共产党新闻网发表天科大马院赵志勇老师理论文章——思政课要善用科学思维方法讲道理','http://news.tust.edu.cn/kdxw/54f661e16b654ec8ae2ac88157828d1c.htm',0),(15,'我大新闻','25\n2022.05','【访企拓岗促就业】 校领导率队走访深圳市裕同包装科技股份有限公司','http://news.tust.edu.cn/kdxw/48a5b1578fbf44a883c152b142b35a67.htm',0),(16,'我大新闻','25\n2022.05','【访企拓岗促就业】校领导带队走访SGS 通标标准技术服务（天津）有限公司','http://news.tust.edu.cn/kdxw/48a5b1578fbf44a883c152b142b35a67.htm',0),(17,'我大新闻','25\n2022.05','【强担当 创业绩】强强联合！天科大在生物医药领域取得系列重大项目','http://news.tust.edu.cn/kdxw/023f33afb13645caa88094d86f2705cf.htm',0),(18,'我大新闻','31\n2022.05','【天科抗疫】炬光引领 同心抗“疫”  ——生物工程学院全体师生在行动','http://news.tust.edu.cn/kdxw/b58435af5c7f402ca2ec08d95363b339.htm',0),(19,'我大新闻','31\n2022.05','【强担当 创业绩】教育部生物学基础实验课程虚拟教研室在天科大设置分教研室','http://news.tust.edu.cn/kdxw/b58435af5c7f402ca2ec08d95363b339.htm',0),(20,'我大新闻','30\n2022.05','【天科抗疫】机械工程学院迎难而上、多措并举  齐心勠力构筑疫情防控阵地“共同体”','http://news.tust.edu.cn/kdxw/9c2c3cdfcab14567ae8ff3e263fbf0c9.htm',0),(21,'我大新闻','30\n2022.05','【访企拓岗促就业】天科大校领导带队走访天津博蕴纯化装备材料科技有限公司','http://news.tust.edu.cn/kdxw/9c2c3cdfcab14567ae8ff3e263fbf0c9.htm',0),(22,'我大新闻','30\n2022.05','【迎盛会 铸忠诚】天科大校领导深入机械学院开展工作调研','http://news.tust.edu.cn/kdxw/8436470826d44b7fa7ab314ee00a7efc.htm',0),(23,'我大新闻','01\n2022.06','【访企拓岗促就业】天科大校领导率队走访天津汽车模具股份有限公司','http://news.tust.edu.cn/kdxw/2ee964ddf7714f9395e1b75f75937ad0.htm',0),(24,'我大新闻','01\n2022.06','【强担当 创业绩】  天科大在多功能纳米纤维素基碳气凝胶领域取得进展','http://news.tust.edu.cn/kdxw/2ee964ddf7714f9395e1b75f75937ad0.htm',0),(25,'我大新闻','01\n2022.06','【迎盛会 铸忠诚】天科大外国语学院举办 “尚言讲坛”第一讲','http://news.tust.edu.cn/kdxw/6dd5d34f6d994e41b4ec61a7fbdfdcbb.htm',0),(26,'我大新闻','01\n2022.06','【青春献礼二十大】天科大召开第八届中国国际“互联网+”大学生创新创业大赛天津科技大学校赛赛务协调沟通会','http://news.tust.edu.cn/kdxw/6dd5d34f6d994e41b4ec61a7fbdfdcbb.htm',0),(27,'我大新闻','01\n2022.06','【青春献礼二十大】科普金课进校园，共育科学追梦人  ——生物、马院联手打造“思政+专业”科普活动','http://news.tust.edu.cn/kdxw/da78b2b0f9394f3b958fef768427269c.htm',0),(28,'我大新闻','01\n2022.06','【访企拓岗促就业】天科大校领导率队走访天津汽车模具股份有限公司','http://news.tust.edu.cn/kdxw/2ee964ddf7714f9395e1b75f75937ad0.htm',0),(29,'我大新闻','01\n2022.06','【强担当 创业绩】  天科大在多功能纳米纤维素基碳气凝胶领域取得进展','http://news.tust.edu.cn/kdxw/2ee964ddf7714f9395e1b75f75937ad0.htm',0),(30,'我大新闻','01\n2022.06','【迎盛会 铸忠诚】天科大外国语学院举办 “尚言讲坛”第一讲','http://news.tust.edu.cn/kdxw/6dd5d34f6d994e41b4ec61a7fbdfdcbb.htm',0),(31,'我大新闻','01\n2022.06','【青春献礼二十大】天科大召开第八届中国国际“互联网+”大学生创新创业大赛天津科技大学校赛赛务协调沟通会','http://news.tust.edu.cn/kdxw/6dd5d34f6d994e41b4ec61a7fbdfdcbb.htm',0),(33,'我大新闻','01\n2022.06','【访企拓岗促就业】天科大校领导率队走访天津汽车模具股份有限公司','http://news.tust.edu.cn/kdxw/2ee964ddf7714f9395e1b75f75937ad0.htm',0),(34,'我大新闻','01\n2022.06','【强担当 创业绩】  天科大在多功能纳米纤维素基碳气凝胶领域取得进展','http://news.tust.edu.cn/kdxw/2ee964ddf7714f9395e1b75f75937ad0.htm',0),(35,'我大新闻','01\n2022.06','【迎盛会 铸忠诚】天科大外国语学院举办 “尚言讲坛”第一讲','http://news.tust.edu.cn/kdxw/6dd5d34f6d994e41b4ec61a7fbdfdcbb.htm',0),(36,'我大新闻','01\n2022.06','【青春献礼二十大】天科大召开第八届中国国际“互联网+”大学生创新创业大赛天津科技大学校赛赛务协调沟通会','http://news.tust.edu.cn/kdxw/6dd5d34f6d994e41b4ec61a7fbdfdcbb.htm',0),(37,'我大新闻','01\n2022.06','【青春献礼二十大】科普金课进校园，共育科学追梦人  ——生物、马院联手打造“思政+专业”科普活动','http://news.tust.edu.cn/kdxw/da78b2b0f9394f3b958fef768427269c.htm',0),(38,'我大新闻','01\n2022.06','【访企拓岗促就业】天科大校领导率队走访天津汽车模具股份有限公司','http://news.tust.edu.cn/kdxw/2ee964ddf7714f9395e1b75f75937ad0.htm',0),(39,'我大新闻','01\n2022.06','【强担当 创业绩】  天科大在多功能纳米纤维素基碳气凝胶领域取得进展','http://news.tust.edu.cn/kdxw/2ee964ddf7714f9395e1b75f75937ad0.htm',0),(40,'我大新闻','01\n2022.06','【迎盛会 铸忠诚】天科大外国语学院举办 “尚言讲坛”第一讲','http://news.tust.edu.cn/kdxw/6dd5d34f6d994e41b4ec61a7fbdfdcbb.htm',0),(41,'我大新闻','01\n2022.06','【青春献礼二十大】天科大召开第八届中国国际“互联网+”大学生创新创业大赛天津科技大学校赛赛务协调沟通会','http://news.tust.edu.cn/kdxw/6dd5d34f6d994e41b4ec61a7fbdfdcbb.htm',0),(42,'我大新闻','01\n2022.06','【青春献礼二十大】科普金课进校园，共育科学追梦人  ——生物、马院联手打造“思政+专业”科普活动','http://news.tust.edu.cn/kdxw/da78b2b0f9394f3b958fef768427269c.htm',0),(43,'我大新闻','03\n2022.06','【媒体聚焦】《人民日报》报道天津科技大学“用微生物描绘红色故事”助力思政教育','http://news.tust.edu.cn/kdxw/e4c149e5f34d4661abd62fe79570c7da.htm',0),(44,'我大新闻','03\n2022.06','【网络中国节·端午】新的开“端” “午”忘母校 ——天科大为因疫情未返津毕业生寄送“归宗粽”礼盒','http://news.tust.edu.cn/kdxw/e4c149e5f34d4661abd62fe79570c7da.htm',0),(45,'我大新闻','01\n2022.06','【访企拓岗促就业】天科大校领导率队走访天津汽车模具股份有限公司','http://news.tust.edu.cn/kdxw/a756945045684dc7bf94c8ea0ae6218c.htm',0),(46,'我大新闻','01\n2022.06','【强担当 创业绩】  天科大在多功能纳米纤维素基碳气凝胶领域取得进展','http://news.tust.edu.cn/kdxw/a756945045684dc7bf94c8ea0ae6218c.htm',0),(47,'我大新闻','01\n2022.06','【迎盛会 铸忠诚】天科大外国语学院举办 “尚言讲坛”第一讲','http://news.tust.edu.cn/kdxw/2ee964ddf7714f9395e1b75f75937ad0.htm',0),(48,'我大新闻','05\n2022.06','【青春献礼二十大】天津科技大学在第二届“外教社•词达人杯”  全国大学生英语词汇能力大赛斩获佳绩','http://news.tust.edu.cn/kdxw/7defbfe484b34e03ab888763a1c798c0.htm',0),(49,'我大新闻','05\n2022.06','【青春献礼二十大】童言童语说“四史” 厚植爱党爱国爱社会主义情怀','http://news.tust.edu.cn/kdxw/7defbfe484b34e03ab888763a1c798c0.htm',0),(50,'我大新闻','04\n2022.06','【网络中国节·端午】新的开“端” “午”忘母校——天科大为因疫情未返津毕业生寄送“归宗粽”礼盒','http://news.tust.edu.cn/kdxw/c639b0c881484069a5a381c68676e30a.htm',0),(51,'我大新闻','04\n2022.06','【强担当 创业绩】天津科技大学郑小伟副教授获批国家社科基金重大项目子课题','http://news.tust.edu.cn/kdxw/c639b0c881484069a5a381c68676e30a.htm',0),(52,'我大新闻','04\n2022.06','【访企拓岗促就业】天科大校领导带队走访万华化学集团','http://news.tust.edu.cn/kdxw/5b24a37fc27946abbc490b83f2711aa9.htm',0),(53,'我大新闻','05\n2022.06','【青春献礼二十大】天津科技大学在第二届“外教社•词达人杯”  全国大学生英语词汇能力大赛斩获佳绩','http://news.tust.edu.cn/kdxw/7defbfe484b34e03ab888763a1c798c0.htm',0),(54,'我大新闻','05\n2022.06','【青春献礼二十大】童言童语说“四史” 厚植爱党爱国爱社会主义情怀','http://news.tust.edu.cn/kdxw/7defbfe484b34e03ab888763a1c798c0.htm',0),(55,'我大新闻','04\n2022.06','【网络中国节·端午】新的开“端” “午”忘母校——天科大为因疫情未返津毕业生寄送“归宗粽”礼盒','http://news.tust.edu.cn/kdxw/c639b0c881484069a5a381c68676e30a.htm',0),(56,'我大新闻','04\n2022.06','【强担当 创业绩】天津科技大学郑小伟副教授获批国家社科基金重大项目子课题','http://news.tust.edu.cn/kdxw/c639b0c881484069a5a381c68676e30a.htm',0),(57,'我大新闻','04\n2022.06','【访企拓岗促就业】天科大校领导带队走访万华化学集团','http://news.tust.edu.cn/kdxw/5b24a37fc27946abbc490b83f2711aa9.htm',0),(58,'我大新闻','06\n2022.06','【访企拓岗促就业】天科大校领导率队走访国家超算天津中心','http://news.tust.edu.cn/kdxw/b0bfc3157a394c7aa476c31cd4956c3f.htm',0),(59,'我大新闻','06\n2022.06','【青春献礼二十大】天津科技大学化工学院闫闻哲获“天津市向上向善好青年”荣誉称号','http://news.tust.edu.cn/kdxw/b0bfc3157a394c7aa476c31cd4956c3f.htm',0),(60,'我大新闻','06\n2022.06','【网络中国节·端午】天科学子端午“粽”情体验：三种口味万余粽子任选','http://news.tust.edu.cn/kdxw/344911de997c46fe81975a9d094098c2.htm',0),(61,'我大新闻','05\n2022.06','【青春献礼二十大】天津科技大学在第二届“外教社•词达人杯”  全国大学生英语词汇能力大赛斩获佳绩','http://news.tust.edu.cn/kdxw/344911de997c46fe81975a9d094098c2.htm',0),(62,'我大新闻','05\n2022.06','【青春献礼二十大】童言童语说“四史” 厚植爱党爱国爱社会主义情怀','http://news.tust.edu.cn/kdxw/48aee5240fe74500ab762229f4c45124.htm',0),(63,'我大新闻','09\n2022.06','【媒体聚焦】中国新闻网采访天科大海洋学院副院长赵亮对保护海洋生态可持续发展看法','http://news.tust.edu.cn/kdxw/6e3ebf385f944c2e8277ae26958af75c.htm',0),(64,'我大新闻','09\n2022.06','【强担当 创业绩】经管学院公共事业管理系教工党支部顺利通过第二批新时代高校党建示范创建和质量创优工作创建单位验收','http://news.tust.edu.cn/kdxw/6e3ebf385f944c2e8277ae26958af75c.htm',0),(65,'我大新闻','08\n2022.06','【天科抗疫】天科大学工队伍：无畏逆行战疫情 温情守护伴成长','http://news.tust.edu.cn/kdxw/b9393f526e654d6d9f5a1f4c9f4115be.htm',0),(66,'我大新闻','08\n2022.06','【媒体聚焦】天津新闻、津云等多家媒体报道天科大海环学院刘宪斌教授团队助力海堤生态化工程','http://news.tust.edu.cn/kdxw/b9393f526e654d6d9f5a1f4c9f4115be.htm',0),(68,'我大新闻','17\n2022.06','【访企拓岗促就业】天科大校领导带队走访天津食品集团有限公司','http://news.tust.edu.cn/kdxw/de3ac66d4ff841968f4cf95f2a926afd.htm',0),(69,'我大新闻','17\n2022.06','【访企拓岗促就业】天科大校领导与泰国易三仓大学孔子学院举行座谈会','http://news.tust.edu.cn/kdxw/de3ac66d4ff841968f4cf95f2a926afd.htm',0),(70,'我大新闻','17\n2022.06','【迎盛会 铸忠诚】天津科技大学关工委举办  “共话百年奋斗，争做时代新人”专题宣讲','http://news.tust.edu.cn/kdxw/149ebc27f9cc4bd08488bafd5c480fe8.htm',0),(71,'我大新闻','17\n2022.06','毕业季 | 知行合一毕业季 动人心“啤”毕业礼——天津科技大学举办啤酒文化节系列活动','http://news.tust.edu.cn/kdxw/149ebc27f9cc4bd08488bafd5c480fe8.htm',0),(72,'我大新闻','16\n2022.06','【迎盛会 铸忠诚】中央马工程首席专家柴尚金研究员  以“中国共产党理论创新的世界性贡献”为题做学术讲座','http://news.tust.edu.cn/kdxw/77ea7e08d6c34001b4f50dc7d0c25871.htm',0),(73,'我大新闻','17\n2022.06','【访企拓岗促就业】天科大校领导带队走访天津食品集团有限公司','http://news.tust.edu.cn/kdxw/de3ac66d4ff841968f4cf95f2a926afd.htm',0),(74,'我大新闻','17\n2022.06','【访企拓岗促就业】天科大校领导与泰国易三仓大学孔子学院举行座谈会','http://news.tust.edu.cn/kdxw/de3ac66d4ff841968f4cf95f2a926afd.htm',0),(75,'我大新闻','17\n2022.06','【迎盛会 铸忠诚】天津科技大学关工委举办  “共话百年奋斗，争做时代新人”专题宣讲','http://news.tust.edu.cn/kdxw/149ebc27f9cc4bd08488bafd5c480fe8.htm',0),(76,'我大新闻','17\n2022.06','毕业季 | 知行合一毕业季 动人心“啤”毕业礼——天津科技大学举办啤酒文化节系列活动','http://news.tust.edu.cn/kdxw/149ebc27f9cc4bd08488bafd5c480fe8.htm',0),(77,'我大新闻','16\n2022.06','【迎盛会 铸忠诚】中央马工程首席专家柴尚金研究员  以“中国共产党理论创新的世界性贡献”为题做学术讲座','http://news.tust.edu.cn/kdxw/77ea7e08d6c34001b4f50dc7d0c25871.htm',0);
/*!40000 ALTER TABLE `news` ENABLE KEYS */;

#
# Structure for table "rb"
#

DROP TABLE IF EXISTS `rb`;
CREATE TABLE `rb` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) DEFAULT NULL COMMENT '新闻来源',
  `ctime` varchar(255) DEFAULT NULL COMMENT '采集时间',
  `title` varchar(500) DEFAULT NULL COMMENT '新闻标题',
  `url` varchar(255) DEFAULT NULL COMMENT 'url链接',
  `status` int(11) DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻表';

#
# Data for table "rb"
#

/*!40000 ALTER TABLE `rb` DISABLE KEYS */;
/*!40000 ALTER TABLE `rb` ENABLE KEYS */;

#
# Structure for table "syslog"
#

DROP TABLE IF EXISTS `syslog`;
CREATE TABLE `syslog` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ctime` varchar(255) DEFAULT '',
  `lineno` varchar(255) DEFAULT NULL,
  `funName` varchar(255) DEFAULT NULL,
  `cmsg` text,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# Data for table "syslog"
#

/*!40000 ALTER TABLE `syslog` DISABLE KEYS */;
INSERT INTO `syslog` VALUES (1,'2022','3','aaa','aa'),(2,'2022','3','aaa','aa'),(3,'111','2','aap','okdfdfd');
/*!40000 ALTER TABLE `syslog` ENABLE KEYS */;

#
# Structure for table "tp"
#

DROP TABLE IF EXISTS `tp`;
CREATE TABLE `tp` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) DEFAULT NULL COMMENT '新闻来源',
  `ctime` varchar(255) DEFAULT NULL COMMENT '采集时间',
  `title` varchar(500) DEFAULT NULL COMMENT '新闻标题',
  `addr` varchar(255) DEFAULT NULL COMMENT 'url链接',
  `status` int(11) DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻表';

#
# Data for table "tp"
#

/*!40000 ALTER TABLE `tp` DISABLE KEYS */;
/*!40000 ALTER TABLE `tp` ENABLE KEYS */;

#
# Structure for table "user"
#

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL COMMENT '用户名',
  `userpwd` varchar(255) DEFAULT NULL COMMENT '密码',
  `status` int(11) DEFAULT '0' COMMENT '权限',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';

#
# Data for table "user"
#

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','admin123',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

#
# Structure for table "yq"
#

DROP TABLE IF EXISTS `yq`;
CREATE TABLE `yq` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) DEFAULT NULL COMMENT '新闻来源',
  `ctime` varchar(255) DEFAULT NULL COMMENT '采集时间',
  `cnumber` varchar(255) DEFAULT NULL COMMENT '国内疫情数据',
  `gwnumber` varchar(255) DEFAULT NULL COMMENT '国外疫情数据',
  `status` int(11) DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻表';

#
# Data for table "yq"
#

/*!40000 ALTER TABLE `yq` DISABLE KEYS */;
INSERT INTO `yq` VALUES (1,'新浪','2022-04-27 09:42:00','604541','15006',0),(2,'新浪','2022-04-27 18:30:00','604564','15006',0),(3,'1','2022-06-06 12:01:00','2962016','17551',0),(4,'1','2022-06-06 12:01:00','2962016','17551',0),(5,'1','2022-06-08 16:00:00','3098302','17829',0),(6,'1','2022-06-08 16:00:00','3098302','17829',0),(7,'1','2022-06-10 08:31:00','3178542','17988',0),(8,'1','2022-06-21 08:53:00','3855272','19842',0),(9,'1','2022-06-21 13:30:00','3891102','19987',0);
/*!40000 ALTER TABLE `yq` ENABLE KEYS */;

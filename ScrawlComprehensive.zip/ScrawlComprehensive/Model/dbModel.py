'''
数据库连接
'''
import pymysql


class dbConnect():
    def __init__(self):
        self.conn = pymysql.connect(user='libai',
                                    password='123456',
                                    database='myjob',
                                    host='127.0.0.1',
                                    charset='utf8')
        self.cursor = self.conn.cursor()

    def dbManage(self, sql=None):
        '''
        实现对数据表里的定义、增加、删除、修改操作
        :param sql:
        :return:
        '''
        flag = False
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            flag = True
        except:
            pass
        return flag

    def dbQuery(self, sql):
        '''
        数据库的查询业务
        :param sql:
        :return:
        '''
        if self.cursor.execute(sql)!= 0:
            return self.cursor.fetchall()
        else:
            return "0"


if __name__ == '__main__':
    # sql = "insert into user values(null,'{}','{}','{}')".format("李白", '123', 1)
    # print(sql)
    # d = dbConnect()
    # d.dbManage(sql=sql)
    # if dbConnect().dbQuery(sql="select * from {} where username='{}'".format("user","李白")):
    #  print(dbConnect().dbQuery(sql="select * from {} where username='{}'".format("user","李白")))
    # else:print("55")
    for i in ["gratuity",'movie', 'mylike', 'society_1', 'society_2', 'university_1', 'university_2', 'university_3',
              'university_4']:
       print(dbConnect().dbQuery(sql="select * from {} where title like '%{}%'".format(i, "天津")))




'''
数据库的业务
'''
import math
from Model.dbModel import dbConnect

db = dbConnect()
''' 针对请求的增删改查业务进行处理'''

'''查询业务'''
'''1.查询所有字段的值'''


def getAllData(tableName):
    return db.dbQuery(sql="select * from {} order by id desc".format(tableName))


'''1.1按照指定的数量查询所有字段的值并返回'''


def getAllDataByPage(tableName, page):
    return db.dbQuery(sql="select * from {} order by id desc limit {},10".format(tableName, 10 * page - 10))


'''1.2获取共有多少页数据'''


def getAllDataPage(tableName):
    totalNumbers = db.dbQuery(sql="select count(id) from {} ".format(tableName))
    return math.ceil(int(totalNumbers[0][0]) / 10)


'''2.根据id来查询对应的值'''


def getDataByID(tableName, id):
    return db.dbQuery(sql="select * from {} where id={}".format(tableName, id))


'''3.根据name来查询用户对应的值'''


# def getDataByName(name):
#     return db.dbQuery(sql="select * from user where username='{}'".format(name))[0]

def getDataByName(tableName,name):
    if db.dbQuery(sql="select * from {} where username='{}'".format(tableName,name))[0]:
        return db.dbQuery(sql="select * from {} where username='{}'".format(tableName,name))[0]
    else:
        return "0"


'''插入数据'''


def insertData(tableName, source, ctime, title, url, url_p):
    sql = "insert into {} values(null,'{}','{}','{}','{}','{}',0)".format(tableName, source, ctime, title, url,
                                                                          url_p)
    print(sql)
    return db.dbManage(sql=sql)


'''删除数据'''


def delData(tableName, id):
    return db.dbManage(sql="delete from {} where id={}".format(tableName, id))


'''修改数据'''


def modifyData(tableName, id, status):
    return db.dbManage(sql="update {} set status={} where id={}".format(tableName, status, id))


'''查询'''


def searchData(kw):
    for i in ['gratuity', 'movie', 'mylike', 'society_1', 'society_2', 'university_1', 'university_2', 'university_3',
              'university_4']:
        if db.dbQuery(sql="select * from {} where title like '%{}%'".format(i, kw)):
            return db.dbQuery(sql="select * from {} where title like '%{}%'".format(i, kw))






'''日志入库'''


def log2db(ctime, lineno, funname, msg):
    return (db.dbManage(sql="insert into dblog values(null,'{}','{}','{}','{}')".format(ctime, lineno, funname, msg)))


'''测试'''

if __name__ == '__main__':
    # print(getDataByName('admin'))
    print(searchData("天津"))
    # print(log2db('111', '23', 'app', 'ok'))
    # insertData("news_1", 0, 0,0,0,0)

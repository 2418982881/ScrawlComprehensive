"""
高校新闻采集模块
"""
from flask import Blueprint, request, render_template, jsonify
import adminProcess
from Controller.Data2DB import mylog

dy = Blueprint("dy", __name__)
log0 = mylog()

# 6v的列表页面
@dy.route("/admin/dy_1")
def result_dy_6v():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None:
        page = 1
    # 增加获取一共多少页的代码
    tableName = 'movie'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['news'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/dy_6v.html", data=data)
'''
全国通缉悬赏信息
'''
from flask import Blueprint, request, render_template, jsonify
import adminProcess
from Controller.Data2DB import mylog
from Controller.sjfetch import run

sj = Blueprint("sj", __name__)
log0 = mylog()

@sj.route("/admin/sjCollect")
def sjCollect():
    if  run():
        return jsonify({'code': 200, 'msg': "爬取成功！"})
    else:
        return jsonify({'code': 200, 'msg': '爬取失败！'})
@sj.route("/admin/sjshow")
def result():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    tableName ='gratuity'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['sj'] = adminProcess.getDataListByPage(tableName, page=int(page))
    return render_template("admin/sj.html", data=data)
@sj.route("/sjshow")
def sj_():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName='gratuity')
    data['currentPage'] = int(page)
    data['sj'] = adminProcess.getDataListByPage(tableName='gratuity', page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/sj.html", data=data)
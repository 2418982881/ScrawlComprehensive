"""
新闻采集模块
"""
from flask import Blueprint, request, render_template, jsonify
import adminProcess

zh = Blueprint("zh", __name__)


@zh.route("/admin/result_zh")
def result_zh():
    print("热榜成功")
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    tableName = 'zh'
    data = {}
    data["kind"]=tableName
    data['totalPage']=adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['zh']=adminProcess.getDataListByPage(tableName,page=int(page))
    return render_template("admin/zh.html",data=data)


'''处理新闻数据采集'''


@zh.route("/admin/zhCollect")
def zhCollect():
    sourceID = request.args.get('source')
    if adminProcess.zhFetch(sourceID):
        return jsonify({'code': 200, 'msg': "爬取成功！"})
    else:
        return jsonify({'code': 200, 'msg': '爬取失败！'})



@zh.route("/admin/zhShow")
def newsShow():
    id = request.args.get('id')
    if adminProcess.zhShow("zh", id):
        return jsonify({'code': 200, 'msg': '删除成功！'})
    else:
        return jsonify({'code': 404, 'msg': '删除不成功！'})

'''
爬虫模块
'''
import requests, json
from bs4 import BeautifulSoup
'''基于css选择器来实现目标的获取解析'''
class Scrawler():
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36 Edg/100.0.1185.36'
        }
    def reqbsGetText(self, url=None, cssselector=None):
        '''获取文本'''
        try:
            rs = requests.get(url, headers=self.headers)
            rs.encoding = rs.apparent_encoding
            bs = BeautifulSoup(rs.text, 'html.parser')
            return [str(item.text).strip() for item in bs.select(selector=cssselector)]
        except:
            pass
    def reqbsGetText_1(self, url=None, cssselector=None):
        '''获取文本'''
        try:
            rs = requests.get(url, headers=self.headers)
            bs = BeautifulSoup(rs.text, 'html.parser')
            return [str(item.text).strip() for item in bs.select(selector=cssselector)]
        except:
            pass
    def reqbsGetJSON(self, url=None):
        '''获取JSON文本'''
        try:
            rs = requests.get(url, headers=self.headers).text
            rs = str(rs)[13:][:-2]
            return dict(json.loads(rs))
        except:
            pass
    def reqbsGetImg(self, url=None, cssselector=None):
        '''图片获取'''
        try:
            rs = requests.get(url, headers=self.headers)
            rs.encoding = rs.apparent_encoding
            bs = BeautifulSoup(rs.text, 'html.parser')
            urls = [item.attrs['src'] for item in bs.select(selector=cssselector)]
            return urls
        except:
            pass
    def reqbsGetHref(self, url=None, cssselector=None):
        '''链接获取'''
        try:
            rs = requests.get(url, headers=self.headers)
            rs.encoding = rs.apparent_encoding
            bs = BeautifulSoup(rs.text, 'html.parser')
            urls = [item.attrs['href'] for item in bs.select(selector=cssselector)]
            return urls
        except:
            pass

# 获取郴州本地的温度
# def getWeatherInfo():
#     url="http://d1.weather.com.cn/sk_2d/101250501.html?_=1681299284537"
#     headers={
#        "Host": "d1.weather.com.cn",
#         "Referer": "http://www.weather.com.cn/",
#         "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36"
#     }
#     re = requests.get(url,headers=headers)
#     re.encoding = re.apparent_encoding
#     str=re.text.replace('"','')
#     for item in str.split(","):
#         if 'cityname' in item:
#             city = item[9:]
#         elif 'temp:' in item:temp=item.split(":")[1]
#         elif 'date' in item:
#             day=item[5:16]
#     return city,temp,day

"""负责处理入库业务"""
import json
import logging
import re
from datetime import datetime
import requests
from bs4 import BeautifulSoup
from Controller import DataFetch
from Model import DataDB as db
scrawler = DataFetch.Scrawler()
'''入库业务'''
'''1.新闻入库  insertData(tableName,source,ctime,title,url):'''


def newsAdd(id):
    if id == '0':
        '''天津科技大学'''
        source = "天津科技大学新闻"
        url = 'http://news.tust.edu.cn/kdxw/'
        count = 0
        w = scrawler.reqbsGetText(url, cssselector='.news-list .date')
        s = scrawler.reqbsGetText(url, cssselector='.news-list .info h2')
        r = scrawler.reqbsGetHref(url, cssselector='.news-list .info a')
        for i in range(0, 9):
            ctime = w[i][2:] + '.' + w[i][0:2]
            title = s[i]
            urls = url + r[i]
            print(ctime, title, urls)
            if db.insertData('university_1', source, ctime, title, urls, urls):
                count = count + 1
            else:
                print("录入失败")
                count = 0
        if count == 5:
            return True
        else:
            return False
    elif id == '1':
        '''湘南学院'''
        source = "湘南学院新闻"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
        }
        url = 'https://www.xnu.edu.cn/html/909/'
        count = 0
        res = requests.get(url, headers=headers)
        res.encoding = res.apparent_encoding
        bs = BeautifulSoup(res.text, 'html.parser')
        tetle = bs.select(selector=".text h3")
        day = bs.select(selector=".date")
        urld = scrawler.reqbsGetHref(url, cssselector=".list-item>ul a")
        src = scrawler.reqbsGetImg(url, cssselector='.content > .maincon-gray.clearfix  a > .pic > img')
        for i in range(0, 9):
            title = ''.join(re.findall('[\u4e00-\u9fa5]', str(tetle[i])))
            w = day[i].text.replace('\n', '')
            ctime = w[2:] + '-' + w[0:2]
            urls = 'https://www.xnu.edu.cn' + urld[i]
            url_p = 'https://www.xnu.edu.cn' + src[i]
            if db.insertData("university_2", source, ctime, title, urls, url_p):
                print("录入成功")
                count = count + 1
            else:
                count = 0
                print("录入失败")
        if count == 9:
            return True
        else:
            return False
    elif id == "2":
        '''北京大学'''
        source = "北京大学"
        count = 0
        url = 'https://news.pku.edu.cn/ttxw/index.htm'
        w = scrawler.reqbsGetText(url, cssselector='.articleList01 .item-txt > div > h3 > a')
        u = scrawler.reqbsGetText(url, cssselector='.articleList01 > ul  span')
        r = scrawler.reqbsGetHref(url, cssselector='.articleList01 .item-txt > div > h3 > a')
        d = scrawler.reqbsGetImg(url, cssselector='.articleList01 .item-img > a > img')
        print(w[0])
        for i in range(0,10):
            w_1 = d[i].replace("..", "https://news.pku.edu.cn/")
            s = r[i].replace("..", "https://news.pku.edu.cn")
            q = scrawler.reqbsGetText(s, cssselector='.article')
            if q!= None:
                x=q[0]
                if db.insertData('university_3', source=source, ctime=u[i], title=w[i], url=s, url_p=w_1,content=x):
                  count = count + 1
                else:
                  count = count + 1
        if count == len(w) - 1:
            return True
        else:
            return False
    elif id == "3":
        '''清华大学'''
        source = "清华大学"
        count = 0
        url = 'https://www.tsinghua.edu.cn/news/zhsx/827.htm'
        t = scrawler.reqbsGetText(url, cssselector='.zttj_img_li .bt')
        d = scrawler.reqbsGetText(url, cssselector='.qhrw2_ul>li>a>.sj')
        u = scrawler.reqbsGetHref(url, cssselector='.qhrw2_ul>li>a')
        src = scrawler.reqbsGetImg(url, cssselector='.zttj_img_li img')

        for i in range(0, len(t)):
            print(u[i])
            s = u[i]
            if s[0:6] == "../../":
                s = u[i].replace("../..", "https://www.tsinghua.edu.cn/")
                print("1")

            else:
                s = u[i].replace("..", "https://www.tsinghua.edu.cn/")
                print("2")

            d_1 = d[i][3:] + "." + d[i][0:2]
            a = 'https://www.tsinghua.edu.cn/' + src[i]
            if db.insertData('university_4', source=source, ctime=d_1, title=t[i], url=s, url_p=a):
                count = count + 1
                print("导入成功")
                print(s)
            else:
                count = 0
        if count == len(t):
            return True
        else:
            return False
        pass


def dyAdd(id):
    if id == '0':
        '''6v电影网'''
        source = "6v电影网"
        url = 'https://www.66s.cc/'
        count = 0
        w = scrawler.reqbsGetText(url, cssselector='#post_container > li > div > div.article > h2 > a')
        s = scrawler.reqbsGetText(url, cssselector='.lt >li >span')
        r = scrawler.reqbsGetHref(url, cssselector='.lt >li > a')
        print(s)
        print(w)
        print(r)

        for i in range(0, 9):
            ctime = w[i]
            title = s[i]
            urls = "https://www.hao6v.tv" + r[i]
            print(urls)
            print(ctime, title, urls)
            if db.insertData('movie', source, ctime, title, urls, "无"):
                count = count + 1
            else:
                count = 0
        if count == 5:
            return True
        else:
            return False
    elif id == '1':
        '''6v电影网'''
        source = "6v电影网"
        url = 'https://www.66s.cc/'
        count = 0
        w = scrawler.reqbsGetText(url, cssselector='#post_container > li > div > div.article > h2 > a')
        s = scrawler.reqbsGetText(url, cssselector='.lt >li >span')
        r = scrawler.reqbsGetHref(url, cssselector='.lt >li > a')
        print(s)

        for i in range(0, 3):
            ctime = w[i]
            title = s[i]
            urls = "https://www.hao6v.tv" + r[i]
            print(urls)
            print(ctime, title, urls)
            if db.insertData('dy_6v', source, ctime, title, urls, "无"):
                count = count + 1
            else:
                count = 0
        if count == 5:
            return True
        else:
            return False


def rbAdd(id):
    if id == '0':
        '''腾讯新闻热榜'''
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
        }
        url = 'https://r.inews.qq.com/gw/event/hot_ranking_list?ids_hash=&offset=0&page_size=10'
        res = requests.get(url=url, headers=headers).text
        dic_1 = json.loads(res)
        count = 0
        dic_2 = dic_1["idlist"]
        sb = dic_2[0]["newslist"][1:]
        for i in sb:
            if db.insertData('society_1', source=i['chlname'], ctime=i['time'], title=i["title"],
                             url=i["surl"], url_p="无"):
                count = count + 1
                print("腾讯新闻热榜导入成功")
            else:
                count = 0
        if count == 5:
            return True
        else:
            return False
    elif id == '1':
        '''百度热榜'''
        source = "百度热榜"
        url = 'https://top.baidu.com/board?tab=realtime'
        count = 0
        w = scrawler.reqbsGetText(url,cssselector='#sanRoot > main > div.container.right-container_2EFJr  .c-single-text-ellipsis')
        s = scrawler.reqbsGetText(url,cssselector='#sanRoot > main > div.container.right-container_2EFJr .hot-index_1Bl1a')
        r = scrawler.reqbsGetHref(url,cssselector='#sanRoot > main .content_1YWBm>a')
        src = scrawler.reqbsGetImg(url,cssselector='#sanRoot > main > div.container.right-container_2EFJr > div  a > img')
        for i in range(0, len(w)):
            if db.insertData('society_2', source, s[i], w[i], r[i], src[i]):
                count = count + 1
            else:
                count = 0
        if count == len(w) - 1:
            return True
        else:
            return False
    elif id == '2':
        '''哔哩哔哩热榜'''
        source = "哔哩哔哩"
        url = 'https://www.bilibili.com/v/popular/rank/all/'
        count = 0
        w = scrawler.reqbsGetText_1(url,
                                    cssselector='#app > div > div.rank-container > div.rank-list-wrap > ul > li:nth-child > div > div.info > a')

        d = scrawler.reqbsGetText_1(url,
                                    cssselector='#app > div > div.rank-container > div.rank-list-wrap .info > div > a > span')
        r = scrawler.reqbsGetHref(url, cssselector='#app > div > div.rank-container > div.rank-list-wrap .info > a')
        p=scrawler.reqbsGetImg(url,cssselector='#app > div > div.rank-container > div.rank-list-wrap > ul > li:nth-child(1) > div > div.img > a > img')
        print(p)
        for i in range(0, len(w)):
            u='http://' + r[i].replace("//", "")
            print(u)
            if db.insertData('mylike_1', source, d[i], w[i], u, "无"):
                print(w[i])
                count = count + 1
            else:
                count = 0
        if count == len(w) - 1:
            return True
        else:
            return False
    pass


def zhAdd(id):
    if id == '0':
        '''征婚网'''
        source = "征婚网"
        url = "https://www.zhenai.com/zhenghun"
        count = 0
        w = scrawler.reqbsGetText(url, cssselector='.member-list .nick-name')
        s = scrawler.reqbsGetText(url, cssselector='.info-block')
        r = scrawler.reqbsGetHref(url, cssselector='.list-item>a')
        for i in range(0, 9):
            name = w[i]
            print(name)
            other = s[i]
            url_1 = r[i]
            if db.insertData('zh', name, other, source, url_1,):
                count = count + 1
                print("征婚网导入成功")
            else:
                count = 0
        if count == 9:
            return True
        else:
            return False
        print(w)
        print(s)
        print(r)



'''
日志相关处理方法
'''


class MyLogHandler(logging.Handler, object):
    """    自定义日志handler    """

    def __init__(self):
        logging.Handler.__init__(self)

    def emit(self, record):
        """        record为一个消息类对象，包括name，asctime、lineno、funcname等属性
        emit函数为自定义handler类时必重写的函数，这里可以根据需要对日志消息做一些处理，比如发送日志到服务器
        发出记录(Emit a record)"""
        try:
            db.log2db(str(datetime.now()), record.lineno,
                      record.funcName, record.getMessage())
        except Exception:
            self.handleError(record)


def mylog():
    # 创建一个日志记录器
    log = logging.getLogger("test_logger")
    log.setLevel(logging.DEBUG)
    # 创建一个日志处理器
    logHandler = MyLogHandler()
    logHandler.setLevel(logging.INFO)
    # 创建一个日志格式器
    formats = logging.Formatter('%(asctime)s - %(name)s - %(lineno)d: %(message)s')
    # 将日志格式器添加到日志处理器中
    logHandler.setFormatter(formats)
    # 将日志处理器添加到日志记录器中
    log.addHandler(logHandler)
    return log


if __name__ == '__main__':

     rbAdd("2")
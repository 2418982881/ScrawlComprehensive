import platform,psutil
from datetime import datetime
from Model import DataDB as db

def get_size(bytes, suffix="B"):
    """
    Scale bytes to its proper format
    e.g:
        1253656 => '1.20MB'
        1253656678 => '1.17GB'
    """
    factor = 1024
    for unit in ["", "K", "M", "G", "T", "P"]:
        if bytes < factor:
            return f"{bytes:.2f}{unit}{suffix}"
        bytes /= factor

def getsysInfo():
    '''
    系统软硬件信息
    :return:
    '''
    #1.运行环境
    data={}
    data['system']=platform.uname().system
    data['node']=platform.uname().node
    data['version']=platform.uname().version
    #2.启动时间
    data['boottime']=datetime.fromtimestamp(psutil.boot_time())
    #3.memory
    data['memoryused']=get_size(psutil.virtual_memory().used)
    data['memoryfree']=get_size(psutil.virtual_memory().free)
    data['memorytotal']=get_size(psutil.virtual_memory().total)
    data['memorypercent']=psutil.virtual_memory().percent
    #4.CPU
    data['cpucount']=psutil.cpu_count(logical=False)
    data['cpupercent']=psutil.cpu_percent()
    data['cpucurrent']=psutil.cpu_freq().current
    #5.disk
    data['diskdevice']=[item.device for item in psutil.disk_partitions()]
    data['diskfstype']=[item.fstype for item in psutil.disk_partitions()]
    data['diskusage']=[psutil.disk_usage(item.mountpoint) for item in psutil.disk_partitions()]
    data['diskMountpoint'] = [item.mountpoint for item in psutil.disk_partitions()]
    data['diskpercent'] = [psutil.disk_usage(item).percent for item in data['diskMountpoint']]
    data['disktotal'] = [get_size(psutil.disk_usage(item).total) for item in data['diskMountpoint']]
    data['diskfree'] = [get_size(psutil.disk_usage(item).free) for item in data['diskMountpoint']]
    data['diskused'] = [get_size(psutil.disk_usage(item).used) for item in data['diskMountpoint']]
    return data


# 读取日志函数
def getsysLog(page):
    return db.getAllDataByPage("login_log",page)

import item as item
import requests
import json
import  re
from bs4 import BeautifulSoup

from Controller import DataFetch

db = DataFetch.Scrawler()
if __name__ == '__main__':
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
    }
    url = 'https://www.xnu.edu.cn/html/909/'
    res = requests.get(url, headers=headers)
    res.encoding = res.apparent_encoding
    bs = BeautifulSoup(res.text, 'html.parser')
    tetle=bs.select(selector=".text h3")
    day = bs.select(selector=".date")
    url_1=db.reqbsGetHref(url,cssselector=".list-item>ul a")
    for i in url_1:
        print(i)
        print(type(i))

        # w=i.text.replace('\n', '')
        # s=w[2:]+'-'+w[0:2]
        # print(s)

    # for item in bs.select(selector=".text h3"):
    #     res1 = ''.join(re.findall('[\u4e00-\u9fa5]',str(item)))
    #     print(res1)
        # res2 = re.sub("[^a-zA-Z0-9\u4e00-\u9fa5]", '', str2)
        # print(res2)

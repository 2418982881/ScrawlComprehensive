import requests
import json
from Controller import DataFetch
from Controller import DataFetch

db = DataFetch.Scrawler()


if __name__ == '__main__':
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
        }
        url = 'https://www.zhihu.com/billboard'

        # res=requests.get(url,headers).text
        # print(res)
        res_1 = db.reqbsGetText(url=url, cssselector=".Card>a")
        print(res_1)
        for i in res_1:
           w=i[2:]
           print(w)

        # dic_1=json.loads(res)
        # dic_2= dic_1["idlist"]
        # # print(dic_2,type(dic_2))
        # # print(dic_2[0],'\n',type(dic_2[0]))
        # # print(dic_2[0]["newslist"])
        # dic_3=dic_2[0]["newslist"]
        # num=0
        # for sb in dic_3[1:]:
        #         num +=1
        #         print('标题为{title},地址为"{surl},来源为{sorse}'.format(title=sb["title"],surl=sb["surl"],sorse=sb['chlname']))
        # print(num)
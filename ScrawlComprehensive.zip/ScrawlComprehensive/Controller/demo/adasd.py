import time
import requests
import webbrowser
from bs4 import BeautifulSoup
from Controller import DataFetch

db = DataFetch.Scrawler()

def ad():
    global a, b
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
    }
    url = 'https://home.szyouth.cn/application/52?type=1000&come_date=2023-6-29&leave_date=2023-7-2'
    url_2 = "https://home.szyouth.cn/application/76?type=1000&come_date=2023-6-29&leave_date=2023-7-2"
    res = requests.get(url, headers=headers)
    res_2 = requests.get(url_2, headers=headers)
    res.encoding = res.apparent_encoding
    res_2.encoding = res_2.apparent_encoding
    bs = BeautifulSoup(res.text, 'html.parser')
    bs_2 = BeautifulSoup(res_2.text, 'html.parser')
    tetle = bs.select(
        selector="div.stationdetails_right_box > div > div > div.stationdetails_right_content_info > ul > "
                 "li.stationdetails_right_content_info_num > span")
    tetle_1 = bs_2.select(
        selector="div.stationdetails_right_box > div > div > div.stationdetails_right_content_info > ul > "
                 "li.stationdetails_right_content_info_num > span")
    a = str(tetle[0].text).strip().split("|", 1)[0].replace(" ", "")[7]
    b = str(tetle_1[0].text).strip().split("|", 1)[0].replace(" ", "")[7]

if __name__ == '__main__':
    for i in range(1, 1000):
        ad()
        if a == "1" or b == "1":
            print("成功")
            webbrowser.open("https://home.szyouth.cn/")
            break
        else:
            print("再次扫描")
        time.sleep(100)
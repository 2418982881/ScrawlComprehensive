import lxml
import requests
from bs4 import BeautifulSoup

html =  """
<html><head><title>The Dormouse's story</title></head>
<body>
<p class="title"><b>The Dormouse's story</b></p>
<p class="story">Once upon a time there were three little sisters; and their names were
<a href="http://example.com/elsie" class="sister" id="link1"><!--Elsie--></a>,
<a href="http://example.com/lacie" class="sister" id="link2">Lacie</a> and
<a href="http://example.com/tillie" class="sister" id="link3">Tillie</a>;
and they lived at the bottom of a well.</p>
<p class="story">...</p>
"""

#1、BeautifulSoup对象
soup = BeautifulSoup(html,'lxml')
print(type(soup))

# #2、Tag对象
print(soup.head,'\n')
print(soup.head.name,'\n')
print(soup.head.attrs,'\n')
print(type(soup.head))
#
# #3、Navigable String对象
print(soup.title.string,'\n')
print(type(soup.title.string))
#
# #4、Comment对象
print(soup.a.string,'\n')
# print(type(soup.a.string))

# #5、结构化输出soup对象
# print(soup.prettify())
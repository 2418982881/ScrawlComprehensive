import requests
import json


if __name__ == '__main__':
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
        }
        url = 'https://r.inews.qq.com/gw/event/hot_ranking_list?ids_hash=&offset=0&page_size=50'
        res = requests.get(url=url, headers=headers).text
        dic_1=json.loads(res)
        print(res)
        dic_2= dic_1["idlist"]
        # print(dic_2,type(dic_2))
        # print(dic_2[0],'\n',type(dic_2[0]))
        dic_3=dic_2[0]["newslist"]
        print(dic_2[0]["newslist"])
        num=0
        for sb in dic_3[1:]:
                num +=1
                print('标题为{title},发布时间为:{time},地址为"{surl}",来源为{sorse}'.format(title=sb["title"],time=sb['time'],surl=sb["surl"],sorse=sb['chlname']))
        print(num)
import requests
from bs4 import BeautifulSoup
import requests

url = 'https://www.bilibili.com/v/popular/history'
headers={
             'User-Agent':'headers={Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.42'}

rs = requests.get(url,headers=headers)
print(rs.text)
bs =BeautifulSoup(rs.text,'html.parser')
str(bs.text).strip()
# s=bs.select(selector='#app > div > div.rank-container > div.rank-list-wrap > ul > li:nth-child > div > div.info > a')

# d = scrawler.reqbsGetText_1(url,
#                             cssselector='#app > div > div.rank-container > div.rank-list-wrap .info > div > a > span')
# r = scrawler.reqbsGetHref(url, cssselector='#app > div > div.rank-container > div.rank-list-wrap .info > a')
# p=scrawler.reqbsGetImg(url,cssselector='#app > div > div.rank-container > div.rank-list-wrap > ul > li:nth-child(1) > div > div.img > a > img')
# print(s)
#     for i in range(0, len(w)):
    #         u='http://' + r[i].replace("//", "")
    #         print(u)
    #         if db.insertData('mylike_1', source, d[i], w[i], u, "无"):
    #             print(w[i])
    #             count = count + 1
    #         else:
    #             count = 0
    #     if count == len(w) - 1:
    #         return True
    #     else:
    #         return False
    # pass
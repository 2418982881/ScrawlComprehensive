# 导入需要的库
import requests
from bs4 import BeautifulSoup
import os

# 设置请求头，模拟浏览器访问
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36'
}


# 定义一个函数，用于获取B站热榜的网页源码
def get_html(url):
    # 发送请求，获取响应
    response = requests.get(url, headers=headers)
    # 判断响应状态码是否为200
    if response.status_code == 200:
        print("成功")
        # 返回响应的文本内容
        return response.text
    else:
        # 打印错误信息
        print('请求失败，状态码为：', response.status_code)


# 定义一个函数，用于解析网页源码，提取图片和标题
def parse_html(html):
    # 创建一个空列表，用于存储图片和标题的信息
    data = []
    # 使用BeautifulSoup解析网页源码
    soup = BeautifulSoup(html, 'lxml')
    # 找到所有的li标签，它们包含了排行榜的信息
    li_list = soup.find_all('li', class_='rank-item')
    # 遍历每个li标签
    for li in li_list:
        # 创建一个空字典，用于存储图片和标题的信息
        item = {}
        # 找到图片的url，它在img标签的data-src属性中
        img_url = li.find('img')['data-src']
        # 找到标题，它在a标签的text属性中
        title = li.find('a', class_='title').text
        # 将图片的url和标题存入字典中
        item['img_url'] = img_url
        item['title'] = title
        # 将字典追加到列表中
        data.append(item)
        print(data)


if __name__ == '__main__':
    url = "https://www.bilibili.com/v/popular/rank/all/"
    f = get_html(url)
    parse_html(f)


import requests
from bs4 import BeautifulSoup
from Model.dbModel import dbConnect

d = dbConnect()


def get_content(id, url, select):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, 'html.parser')
    if id == 1:
        '''爬取文字'''
        return [str(item.text).strip() for item in soup.select(select)]
    elif id == 2:
        '''爬取图片链接'''
        return [item.attrs['src'] for item in soup.select(select)]
    elif id == 3:
        '''爬取网址'''
        return [item.attrs['href'] for item in soup.select(select)]

def run():
    for page in range(1, 6):
        url = f"https://www.dingruxin.com/criminal_screen.html?emergent=1&page={page}"
        '''姓名和犯罪类型'''
        re_0 = get_content(1, url,
                           "body > section > div > div.screen_criminal_list  div.screen_criminal_item_title > div.screen_criminal_item_name")
        '''简介'''
        re_1 = get_content(1, url, "body > section > div > div.screen_criminal_list  div.screen_criminal_item_desc")
        '''金额'''
        re_2 = get_content(1, url,
                           "body > section > div > div.screen_criminal_list   div.screen_criminal_item_title > div.screen_criminal_item_price")
        '''时间'''
        re_3 = get_content(1, url,
                           'body > section > div > div.screen_criminal_list  div.screen_criminal_item_other > div.screen_criminal_item_time')
        '''发布地点'''
        re_4 = get_content(1, url,
                           "body > section > div > div.screen_criminal_list  div.screen_criminal_item_other > div.screen_criminal_item_release")
        '''头像'''
        re_5 = get_content(2, url,
                           'body > section > div > div.screen_criminal_list  div.screen_criminal_item_img > img')
        re_6 = get_content(3, url, "body > section > div > div.screen_criminal_list > a")
        print(f"第{page}页")
        for s in range(0, len(re_1)-1):
            sql = "insert into other values(null,'{}','{}','{}','{}','{}','{}','{}','{}')".format(re_0[s][:-1],re_0[s][-1],re_2[s],re_1[s],re_4[s],re_3[s],re_6[s],re_5[s])
            d.dbManage(sql)

'''
实现系统的监控
'''
from flask import Blueprint, render_template, jsonify, request
import adminProcess

sysm = Blueprint("sysm", __name__)


@sysm.route('/admin/sysmonitor')
def systeminfo():
    '''
    获取系统信息
    :return:
    '''
    return render_template('/admin/sysmonitor.html')


# 获取系统监控信息
@sysm.route('/admin/systeminfoj')
def systeminfoj():
    return jsonify({"data": adminProcess.getsysInfo(), "code": 200})


# 设定日志路由
@sysm.route('/admin/systemlog')
def systemlog():
    page = request.args.get('page')
    if not page: page = 1
    data = {}
    data['log'] = adminProcess.getSysLog(page=int(page))
    data['currentPage'] = int(page)
    data['totalPage'] = adminProcess.getDataListPage(tableName='login_log')
    print(data['totalPage'])
    return render_template("admin/syslog.html", data=data)

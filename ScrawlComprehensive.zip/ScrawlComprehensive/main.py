from flask import Flask, render_template, request, redirect, Blueprint
from news import news
from zh import zh
from front import user
from rb import rb
from sysinfo import sysm
from sj import sj
from dy import dy
from mylike import like

app = Flask(__name__)
app.secret_key = '****----'
urls = [news, user, sysm, rb, zh, sj, dy, like]  # 将五个路由构建数组
for url in urls:
    app.register_blueprint(url)  # 将五个路由均实现蓝图注册到主app应用上

if __name__ == '__main__':
    print("温馨提示：请确保网络连通\n")
    url

    print("如果没有显示运行日志，请更换port")
    app.run(port=3003)

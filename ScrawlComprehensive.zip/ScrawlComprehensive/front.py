'''
前端业务
'''
from flask import Blueprint, request, render_template, jsonify, redirect, session
import adminProcess
from Controller.Data2DB import mylog

user = Blueprint("user", __name__)
log0 = mylog()


# 前端首页
@user.route("/")
def front():
    data = {}
    return render_template("begin.html", data=data)


''' 后台登录处理'''


@user.route("/admin/login", methods=['POST'])
def adminlogin():
    username = request.form['name']
    userpwd = request.form['password']
    if adminProcess.login(username, userpwd) == 1:
        session['username'] = username
        print("进入管理员界面")
        return render_template("admin/index.html")
    elif adminProcess.login(username, userpwd) == 2:
        print("进入用户页面")
        data = {}
        return redirect('/news_1')
    else:
        data = {}
        return redirect("/")


# 美图展示路由
@user.route("/zhShow")
def zh():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName='zh')
    data['currentPage'] = int(page)
    data['zh'] = adminProcess.getDataListByPage(tableName='zh', page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/zh.html", data=data)

@user.route("/f")
def f():
    data = {}
    return render_template("front/admin.html",data=data)


@user.route("/f_1",methods=['POST'])
def f_1():
    data = {}
    adminProcess.zhuce(request.form['name'],request.form['password'])
    return render_template("front/admin.html",data=data)



@user.route("/dy")
def dy():
    # 获取来源的参数
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    data = {}
    data['totalPage'] = adminProcess.getDataListPage(tableName='movie')
    data['currentPage'] = int(page)
    data['dy'] = adminProcess.getDataListByPage(tableName='movie', page=int(page))
    log0.info("进入新闻页面成功")
    return render_template("front/dy.html", data=data)


'''搜索请求'''


@user.route("/searchsss", methods=['POST'])
def search():
    content = request.form['name']
    data = {}
    data["title"] = content
    data["s"]=adminProcess.searchdata(content)
    print(data["s"])
    if  data["s"]!='0':
      data["t"]=len(data["s"])
    else:
        data["t"]=0
        print(data["t"])
    return render_template("front/search_1.html",data=data)
@user.route("/search")
def search_1():
    data = {}
    return render_template("front/search.html",data=data)

''' 后台登录注销'''


@user.route("/admin/logout")
def adminlogout():
    session.clear()
    return jsonify({'code': 200, 'msg': '注销成功！'})


@user.route("/user")
def admintouser():
    print("进入用户页面")
    data = {}
    log0.info("获取天气成功")
    return render_template("front/search.html", data=data)


# 进入系统后台路由，要求登录
@user.route("/admin")
def admin():
    return render_template("admin/index.html")


# 登录成果后进入系统管理首页
@user.route("/admin/index")
def admin_index():
    return render_template("admin/index.html")


@user.route("/admin/userd")
def admin_user():
    page = request.args.get('page')
    if page is None: page = 1
    # 增加获取一共多少页的代码
    tableName = 'user'
    data = {}
    data["kind"]=tableName
    data['totalPage'] = adminProcess.getDataListPage(tableName)
    data['currentPage'] = int(page)
    data['user'] = adminProcess.getDataListByPage(tableName, page=int(page))
    log0.info("进入用户管理页面成功")
    return render_template("admin/user.html",data=data)


@user.route("/admin/Delete")
def newsDelete():
    kind = request.args.get('kind')
    print(kind.split(",",1))
    if adminProcess.newsDelete(kind.split(",",1)[0], kind.split(",",1)[1]):
        print("删除成功")
        redirect("/")
        return  jsonify({'code': 200, 'msg': '删除成功！'})

    else:
        print("删除失败")
        return jsonify({'code': 404, 'msg': '删除不成功！'})

if __name__=="__main__":
    if adminProcess.newsDelete("user", 12):
       print("成功")

